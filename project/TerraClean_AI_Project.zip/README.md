# 🌿 TerraClean AI — Smart Waste Overflow & Bio-Filtration System

[![License: MIT](https://img.shields.io/badge/License-MIT-emerald.svg)](LICENSE)
[![Status: Prototype Active](https://img.shields.io/badge/Status-Prototype%20Active-brightgreen.svg)]()
[![Wokwi Simulator](https://img.shields.io/badge/Wokwi-Simulation%20Live-0284c7.svg)](https://wokwi.com/projects/476153080132205569)

**TerraClean AI** is an AI-powered smart urban waste monitoring dashboard and bio-filtration concept designed for college demonstrations, hackathons, SIH presentations, and IoT showcases.

It integrates modern **HC-SR04 ultrasonic IoT sensing** with **natural terracotta clay and activated charcoal bio-filtration** to prevent waste overflow while mitigating foul odors around public dustbins.

---

## 📌 Key Features

1. **Live Waste Level Telemetry**: Real-time ultrasonic distance and fill percentage calculations.
2. **Visual Smart Dustbin Simulator**: Graphic animated dustbin showing level changes with interactive controls.
3. **Critical Overflow Alert System**: Automatic alert banner, audio buzzer synth, and alert LED status.
4. **Natural Bio-Filtration Layer**: 6-layer cross-section combining activated charcoal and porous terracotta clay for odor control.
5. **Real-Time Chart.js Graph**: Live historical telemetry curves.
6. **Hardware & Wokwi Integration**: Embedded interactive 3D Wokwi circuit simulator and copyable Arduino C/C++ firmware.
7. **Municipal Multi-Bin Fleet**: City grid monitoring (`BIN-001` to `BIN-004`) with dispatch truck action.
8. **System Alert History & Report Exporter**: Historical overflow log table and one-click PDF report exporter.

---

## 🛠️ Circuit & Hardware Components

- **Arduino UNO** (ATmega328P Microcontroller)
- **HC-SR04** Ultrasonic Distance Sensor
- **16x2 LCD Display** (I2C Module)
- **Active Piezo Alarm Buzzer**
- **Alert LED Indicator** (+ 220Ω Resistor)
- **Replaceable Bio-Filter Cassette** (Activated Charcoal + Porous Clay Vessel)

---

## 🚀 How to Run Locally

1. Download or clone this repository.
2. Double-click **`start_dashboard.bat`** to launch the dashboard in your browser.
3. Alternatively, open `index.html` directly in Google Chrome or Microsoft Edge.

---

## 🔗 Live Wokwi Hardware Simulation
Interactive Hardware Circuit Link: [https://wokwi.com/projects/476153080132205569](https://wokwi.com/projects/476153080132205569)
